<?php

namespace App;

class Post extends Model
{
     protected $fillable = ['title', 'content'];
   
}